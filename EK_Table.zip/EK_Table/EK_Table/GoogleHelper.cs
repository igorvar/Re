﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3;
using Google.Apis.Sheets.v4;
using Google.Apis.Util.Store;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EK_Table
{
    internal class GoogleHelper
    {
        private readonly string token;
        private readonly string sheetFileName;
        //private string sheetTableId;
        public string SheetTableId { get; private set; }
        private readonly string appName;
        private string[] scopes = new string[]
        {
            DriveService.Scope.Drive,
            SheetsService.Scope.Spreadsheets
        };
        private UserCredential credentionals;
        private DriveService driveService;
        private SheetsService sheetsService;
        const string sheetHours = "HOURS";
        const string sheetClients = "CLIENTS";
        const string sheetPayments = "PAYMENTS";

        public GoogleHelper(string Token, string SheetFileName, string ApplicationName/*string? ApplicationName = "UnknownApp"*/)
        {
            this.token = Token;
            sheetFileName = SheetFileName;
            appName = ApplicationName;
            InitFile();
            
        }
        private async void InitFile()
        {
            string credentionalPath = Path.Combine(Environment.CurrentDirectory, ".credentionals", appName);
            using (var strm = new MemoryStream(Encoding.UTF8.GetBytes(token)))
            {
                this.credentionals = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                    clientSecrets: GoogleClientSecrets.FromStream(strm).Secrets,
                    scopes: scopes,
                    user: "user",
                    taskCancellationToken: CancellationToken.None,
                    dataStore: new FileDataStore(credentionalPath, true)
                    );
            }
            driveService = new DriveService(new Google.Apis.Services.BaseClientService.Initializer
            {
                HttpClientInitializer = this.credentionals,
                ApplicationName = appName,
            });
            Google.Apis.Drive.v3.FilesResource.ListRequest diskReq = driveService.Files.List();
            diskReq.Q = $"name='{this.sheetFileName}'";
            Google.Apis.Drive.v3.Data.FileList diskResp = diskReq.Execute();
            switch (diskResp.Files.Count)
            {
                case 0:
                    throw new FileNotFoundException("No found table", sheetFileName);
                case 1:
                    SheetTableId = diskResp.Files[0].Id;
                    //return;// true;
                    break;
                default:
                    throw new FileNotFoundException($"Not unique fileName ({diskResp.Files.Count})", sheetFileName);
            }
            sheetsService = new SheetsService(new Google.Apis.Services.BaseClientService.Initializer
            {
                HttpClientInitializer = this.credentionals,
                ApplicationName = appName,
            });
            Google.Apis.Sheets.v4.SpreadsheetsResource.GetRequest sheetReq = sheetsService.Spreadsheets.Get(SheetTableId);
            Google.Apis.Sheets.v4.Data.Spreadsheet sheetResp = sheetReq.Execute();
            bool isSheetHours = false;
            bool isSheetClients = false;
            bool isSheetPayments = false;
            foreach (Google.Apis.Sheets.v4.Data.Sheet sht in sheetResp.Sheets)
                switch (sht.Properties.Title)
                {
                    case sheetHours:    isSheetHours = true; break;
                    case sheetClients:  isSheetClients = true; break;
                    case sheetPayments: isSheetPayments = true; break;
                }
            if (!isSheetHours)
                throw new ArgumentOutOfRangeException($"In file {sheetResp.Properties.Title} must be sheets: {sheetHours}, {sheetClients} and {sheetPayments}. Sheet {sheetHours} is missing");
            if (!isSheetClients)
                throw new ArgumentOutOfRangeException($"In file {sheetResp.Properties.Title} must be sheets: {sheetClients}, {sheetHours} and {sheetPayments}. Sheet {sheetClients} is missing");
            if (!isSheetPayments)
                throw new ArgumentOutOfRangeException($"In file {sheetResp.Properties.Title} must be sheets: {sheetPayments}, {sheetClients} and {sheetHours}. Sheet {sheetPayments} is missing");
        }


        internal async Task<bool> Start()
        {
            string credentionalPath = Path.Combine(Environment.CurrentDirectory, ".credentionals", appName);
            using (var strm = new MemoryStream(Encoding.UTF8.GetBytes(token)))
            {
                this.credentionals = await GoogleWebAuthorizationBroker.AuthorizeAsync(
                    clientSecrets: GoogleClientSecrets.FromStream(strm).Secrets,
                    scopes: scopes,
                    user: "user",
                    taskCancellationToken: CancellationToken.None,
                    dataStore: new FileDataStore(credentionalPath, true)
                    );
            }
            driveService = new DriveService(new Google.Apis.Services.BaseClientService.Initializer
            {
                HttpClientInitializer = this.credentionals,
                ApplicationName = appName,
            });

            Google.Apis.Drive.v3.FilesResource.ListRequest diskReq = driveService.Files.List();
            diskReq.Q = $"name='{this.sheetFileName}'";
            Google.Apis.Drive.v3.Data.FileList diskResp = diskReq.Execute();
            switch (diskResp.Files.Count)
            {
                case 0:
                    throw new FileNotFoundException("No found table", sheetFileName);
                case 1:
                    SheetTableId = diskResp.Files[0].Id;
                    return true;
                    break;
                default:
                    throw new FileNotFoundException($"Not unique fileName ({diskResp.Files.Count})", sheetFileName);
            }

        }
    }
}
