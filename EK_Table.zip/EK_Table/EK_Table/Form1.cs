

using System.Data;

namespace EK_Table
{
    public partial class Form1 : Form
    {
        private readonly string _appName;
        private readonly string _spreadsheetFileId;
        private readonly string _token;
        private readonly GoogleDatabase _db;

        //const string SHEET_HOURS = "HOURS";
        //const string SHEET_CLIENTS = "CLIENTS";
        //const string SHEET_PAYMENTS = "PAYMENTS";

        private readonly string TABLE_JOURNAL = GoogleDatabase.Tables.JOURNAL.ToString();
        public Form1()
        {
            InitializeComponent();
            System.Xml.XmlDocument doc = new();
            doc.Load("TempData.xml");
            _appName = doc.DocumentElement.GetAttribute("ApplicationName");
            _spreadsheetFileId = doc.DocumentElement.GetAttribute("FileId");
            _token = doc.DocumentElement.GetAttribute("Token");
            _db = new GoogleDatabase(
                ApplicationName: _appName,
                SpreadsheetFileId: _spreadsheetFileId,
                token: _token
                );
        }

        private void btnSetting_Click(object sender, EventArgs e)
        {
            frmSettings frmSet = new();
            frmSet.ShowDialog();
        }

        private void btnDB_Click(object sender, EventArgs e)
        {
            //_db.SetRow(SHEET_CLIENTS, 10, new object[] { 1, "d", true });
            _db.SetRow(Sheet: "I_Integration", 4, new object[] { "keytool error: java.security.cert.CertificateParsingException: signed overrun, bytes = 917" ,
            "keytool -import -alias MyAlias -file MySert.pem -keystore store.jks -storepass Pass -keypass Pass -noprompt" });

            _db.SetRow("I_Integration", 5, new object[] { "keytool -genkey -alias MyAlias -keystore store.jks -keyalg RSA -sigalg SHA256withRSA -dname \"cn=*.MyComp.com\" -storepass Pass -keypass Pass" });
            _db.SetRow("I_Integration", 6, new object[] { "<?xml version=\"1.0\" encoding=\"utf-8\"?>\r\n<ListOfOrder>\r\n\t<Order>\r\n\t\t<Name>1-188429049</Name>\r\n\t\t<ListOfOrderItem>\r\n\t\t\t<OrderItem>\r\n\t\t\t\t<LineNumber>1</LineNumber>\r\n\t\t\t\t<OrderItem>\r\n\t\t\t\t\t<LineNumber>2</LineNumber>\r\n\t\t\t\t</OrderItem>\r\n\t\t\t</OrderItem>\r\n\t\t</ListOfOrderItem>\r\n\t</Order>\r\n</ListOfOrder>" });
            //object[] x = _db.GetRange(SHEET_HOURS, 10);
            //var x = _db.GetTable(SHEET_HOURS);
            //_db.GetTable(GoogleDatabase.Tables.PAYMENTS.ToString());
            //var o = x.ToArray();


            /*_db.FillTableFromFile(_db.MainDataSet.Tables[SHEET_HOURS]);
            _db.FillTableFromFile(_db.MainDataSet.Tables[SHEET_CLIENTS]);
            _db.FillTableFromFile(_db.MainDataSet.Tables[SHEET_PAYMENTS]);

            DataTable tblHours = _db.MainDataSet.Tables[SHEET_HOURS];
            DataTable tblClients = _db.MainDataSet.Tables[SHEET_CLIENTS];
            DataTable tblPayments = _db.MainDataSet.Tables[SHEET_PAYMENTS];



            DataTable jrn = BuildJournal(tblHours, tblClients);*/
            //dgvJournal.DataSource = jrn;
            dgvJournal.DataSource = _db.MainDataSet.Tables[TABLE_JOURNAL];

        }
        DataTable BuildJournal(DataTable Hours, DataTable Clients)
        {
            DataTable jrn = new DataTable();
            jrn.Columns.Add("HOUR", typeof(TableVal)/*typeof(DateTime)*/);
            DataRow jrnHourRow;
            DataRow[] hoursRows;
            foreach (DataRow row in Clients.Select("IS_ACTIVE = TRUE", "ORDER ASC"))
                jrn.Columns.Add((string)row["NAME"], typeof(TableVal));

            hoursRows = Hours.Select("", "TIME ASC");
            foreach (DataRow row in hoursRows)
            {
                if (jrn.Rows.Count == 0 || (DateTime)(((TableVal)jrn.Rows[jrn.Rows.Count - 1]["HOUR"]).Val) != (DateTime)row["TIME"])
                {
                    jrnHourRow = jrn.NewRow();
                    jrnHourRow["HOUR"] = new TableVal(Val: (DateTime)row["TIME"], RowNumber: (uint)row["ROW_ID"]);
                }
                else
                {
                    jrnHourRow = jrn.Rows[jrn.Rows.Count - 1];
                    ((TableVal)jrnHourRow["HOUR"]).AddRowNumber((uint)row["ROW_ID"]);
                }
                try
                {
                    jrnHourRow[row["CLIENT"].ToString()] = new TableVal(Val: /*(sbyte)*/row["STATUS"], RowNumber: (uint)row["ROW_ID"]);
                }
                catch (ArgumentException ex)
                {
                    if (jrn.Columns[row["CLIENT"].ToString()] != null)
                        throw ex;
                    jrn.Columns.Add(row["CLIENT"].ToString());
                    jrnHourRow[row["CLIENT"].ToString()] = new TableVal(Val: (sbyte)row["STATUS"], RowNumber: (uint)row["#ROWNUM"]);
                }
                if (jrnHourRow.RowState == DataRowState.Detached)
                    jrn.Rows.Add(jrnHourRow);
            }
            jrn.RowChanged += Jrn_RowChanged;
            //jrn.ColumnChanged += Jrn_ColumnChanged;
            return jrn;
        }

        /*private void Jrn_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            TableVal v = (TableVal)(e.ProposedValue);
            uint[] rowIds = v.RowNumbers;
            object val = v.Val;
            DataRow[] rowsById;
            DataTable tbl = _db.MainDataSet.Tables[SHEET_HOURS];
            foreach (uint rowId in rowIds)
            {
                rowsById = tbl.Select($"ROW_ID='{rowId}'");
                if (rowsById.Length != 1)
                    if (rowsById.Length == 0) throw new Exception($"Not found ROW_ID = '{rowId}' in table {tbl.TableName}");
                    else throw new Exception($"ROW_ID {rowId} is not unique in {tbl.TableName}");
                rowsById[0][e.Column.ColumnName == "HOUR" ? "TIME" : "STATUS"] = val;
                //_db.MainDataSet.Tables[SHEET_HOURS].Rows[(int)rowId][e.Column.ColumnName == "HOUR" ? "TIME" : "STATUS"] = val;
            }
        }*/

        private void Jrn_RowChanged(object sender, DataRowChangeEventArgs e)
        {
            //    throw new NotImplementedException();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dgvJournal_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {

        }

        private void dgvJournal_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvJournal_CellValuePushed(object sender, DataGridViewCellValueEventArgs e)
        {

        }

        private void dgvJournal_CellErrorTextNeeded(object sender, DataGridViewCellErrorTextNeededEventArgs e)
        {

        }

        private void dgvJournal_CellValueNeeded(object sender, DataGridViewCellValueEventArgs e)
        {

        }

        private void dgvJournal_DataError(object sender, DataGridViewDataErrorEventArgs e)
        {
            string EnteredText = dgvJournal[e.ColumnIndex, e.RowIndex].EditedFormattedValue.ToString();
            DataTable src = (DataTable)dgvJournal.DataSource;
            TableVal v;
            //src.Rows[e.RowIndex][e.ColumnIndex]
            if (
                e.RowIndex == src.Rows.Count || //new row
                src.Rows[e.RowIndex][e.ColumnIndex].GetType() == typeof(DBNull)
                )
                v = new TableVal(EnteredText, 0);
            else
                v = new TableVal((TableVal)src.Rows[e.RowIndex][e.ColumnIndex], EnteredText);

            src.Rows[e.RowIndex][e.ColumnIndex] = v;
        }

        private void dgvJournal_CellErrorTextChanged(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvJournal_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {

        }
    }

    /// <summary>
    /// Data for cell of showing table. 
    /// 
    /// </summary>
    struct TableVal : IComparable<TableVal>//, IConvertible//, IComparer<TableVal>
    {
        private List<uint> _rowNumbers;//= new List<uint>(5);

        public TableVal(object Val, uint RowNumber)
        {
            this.Val = Val;
            _rowNumbers = new List<uint> { RowNumber };
            //{RowNumber};
            //_rowNumbers[0] = RowNumber;
        }
        public TableVal(TableVal Original, object NewVal)
        {
            this.Val = NewVal;
            _rowNumbers = Original._rowNumbers;
        }
        public void AddRowNumber(uint RowNumber)
        {
            _rowNumbers.Add(RowNumber);
        }

        public void UpdateDefaultId(uint Id)
        {
            //foreach (uint id in _rowNumbers)
            for (int i = 0; i < _rowNumbers.Count; i++)
                if (_rowNumbers[i] == 0) _rowNumbers[i] = Id;
        }
        public object Val { get; private set; }
        public uint[] RowNumbers { get { return _rowNumbers.ToArray(); } }


        public int CompareTo(TableVal other)
        {
            return ((IComparable)other.Val).CompareTo((IComparable)Val);

            //throw new NotImplementedException();
        }
        public override string ToString()
        {
            //return $"{(_rowNumbers.Count == 1 ? _rowNumbers[0].ToString() : RowNumbers.ToString())} ({Val.ToString()})";
            return Val.ToString();

        }

        //public TypeCode GetTypeCode()
        //{
        //    throw new NotImplementedException();
        //}

        //public bool ToBoolean(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public byte ToByte(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public char ToChar(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public DateTime ToDateTime(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public decimal ToDecimal(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public double ToDouble(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public short ToInt16(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public int ToInt32(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public long ToInt64(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public sbyte ToSByte(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public float ToSingle(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public string ToString(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public object ToType(Type conversionType, IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public ushort ToUInt16(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public uint ToUInt32(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //public ulong ToUInt64(IFormatProvider? provider)
        //{
        //    throw new NotImplementedException();
        //}

        //int IComparer<TableVal>.Compare(TableVal x, TableVal y)
        //{
        //    ((IComparable)x.Val).CompareTo(((IComparable)x.Val));
        //}
    }
}