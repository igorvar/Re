﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace EK_Table
{
    public partial class frmSettings : Form
    {
        public frmSettings()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //if (!File.Exists(txtTokenFile.Text))
            //    throw new FileNotFoundException("Not found file", txtTokenFile.Text);
            //string tokenJson = File.ReadAllText(txtTokenFile.Text);


            GoogleHelper helper = new GoogleHelper(
                Properties.Settings.Default.Token,
                txtTable.Text,
                Properties.Settings.Default.ApplicationName);
            //var c = helper.Start().Result;
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml("<?xml version=\"1.0\" encoding=\"utf-8\"?><Settings/>");
            xmlDoc.DocumentElement.SetAttribute("ApplicationName", Properties.Settings.Default.ApplicationName);
            
            
            //SheetTableId = 1VIMF6N1pCBhUsRn-6PS5kUflplhDIYFxUTr274Oo5WQ
            xmlDoc.DocumentElement.SetAttribute("FileId", helper.SheetTableId);
            xmlDoc.DocumentElement.SetAttribute("Token", Properties.Settings.Default.Token);
            xmlDoc.Save("TempData.xml");

        }
    }
}
