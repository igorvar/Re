﻿namespace EK_Table
{
    partial class frmSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtTable = new TextBox();
            label2 = new Label();
            btnSave = new Button();
            SuspendLayout();
            // 
            // txtTable
            // 
            txtTable.Location = new Point(111, 41);
            txtTable.Name = "txtTable";
            txtTable.Size = new Size(285, 23);
            txtTable.TabIndex = 0;
            txtTable.Text = "eSEKkatandB";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(52, 44);
            label2.Name = "label2";
            label2.Size = new Size(53, 15);
            label2.TabIndex = 1;
            label2.Text = "Table file";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(90, 115);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(75, 23);
            btnSave.TabIndex = 2;
            btnSave.Text = "button1";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // frmSettings
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(471, 174);
            Controls.Add(btnSave);
            Controls.Add(label2);
            Controls.Add(txtTable);
            Name = "frmSettings";
            ShowInTaskbar = false;
            Text = "frmSettings";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtTable;
        private Label label2;
        private Button btnSave;
    }
}