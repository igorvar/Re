﻿using Google.Apis.Auth.OAuth2;
using Google.Apis.Drive.v3.Data;
using Google.Apis.Sheets.v4;
using Google.Apis.Sheets.v4.Data;
using Google.Apis.Util.Store;
using Microsoft.Win32;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Data;
//using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace EK_Table
{
    internal class GoogleDatabase
    {

        //private UserCredential credentionals;
        public enum Tables { HOURS, CLIENTS, PAYMENTS, JOURNAL };



        private readonly SheetsService _sheetsService;
        private readonly string _appName;
        private readonly string _spreadsheetFileId;
        //private readonly DataSet _dataset;
        public DataSet MainDataSet { get; private set; }

        private async Task<UserCredential> GetCredential(string token)
        {
            string credentionalPath = Path.Combine(Environment.CurrentDirectory, ".credentionals", _appName);
            using (var strm = new MemoryStream(Encoding.UTF8.GetBytes(token)))
            {
                //this.credentionals = 
                return await GoogleWebAuthorizationBroker.AuthorizeAsync(
                clientSecrets: GoogleClientSecrets.FromStream(strm).Secrets,
                scopes: new string[] { SheetsService.Scope.Spreadsheets },
                user: "user",
                taskCancellationToken: CancellationToken.None,
                dataStore: new FileDataStore(credentionalPath, true)
                );
            }
        }
        public GoogleDatabase(string ApplicationName, string token, string SpreadsheetFileId)
        {
            _appName = ApplicationName;
            _spreadsheetFileId = SpreadsheetFileId;
            _sheetsService = new SheetsService(new Google.Apis.Services.BaseClientService.Initializer
            {
                HttpClientInitializer = GetCredential(token).Result,
                ApplicationName = ApplicationName,
            });

            TableDifinitions[] tabDifs = new TableDifinitions[]
            {
                new TableDifinitions(
                    Tables.HOURS.ToString(),
                    new string[]{"ROW_ID", "TIME", "CLIENT", "STATUS"},
                    new Type[]{typeof(uint), typeof(DateTime), typeof(string), typeof(sbyte) }
                    ),
                new TableDifinitions(
                    Name: Tables.CLIENTS.ToString(),
                    new string[]{"ROW_ID",        "NAME",          "PHONE1",       "PHONE2",     "ORDER",     "IS_ACTIVE",   "ACTIVE_FROM"},
                    new Type[]  {typeof(uint), typeof(string), typeof(string), typeof(string), typeof(short), typeof(bool), typeof(DateTime) }
                    ),
                new TableDifinitions(
                    Name:Tables.PAYMENTS.ToString(),
                    ColumnNames: new string[]   {"ROW_ID",    "DATE",            "CLIENT",       "AMOUNT",       "TYPE",       "PAYMENT_CHECK_ISSUED" },
                    ColumnDatatypes : new Type[]{typeof(uint), typeof(DateTime), typeof(string), typeof(Decimal), typeof(byte), typeof(byte)}
                    )
                };

            MainDataSet = new DataSet();
            foreach (TableDifinitions t in tabDifs)
            {
                MainDataSet.Tables.Add(t.NewTable());
            }

            foreach (DataTable dt in MainDataSet.Tables)
            {
                FillTableFromFile(dt);
                dt.ColumnChanged += FileTable_ColumnChanged;
                //dt.TableNewRow += FileTable_NewRow;
                dt.RowChanged += FileTable_NewRow;
            }

            MainDataSet.Tables.Add(BuildJournal());


            /*foreach (DataTable t in _dataset.Tables)
            {
                FillTable(t);
            }*/


        }



        internal void SetRow(string Sheet, uint RowNumber, object[] Values)
        {//29:57
            string range = $"INDIRECT(\"{Sheet}!R{RowNumber}C1:R{RowNumber}C[{Values.Length}]\"; FALSE)";
            range = $"{Sheet}!A{RowNumber}:{RowNumber}";

            //range = "[[1, 2],[3,4]]";


            var values = new List<List<object>> { new List<object>(Values) };
            SpreadsheetsResource.ValuesResource.UpdateRequest request = _sheetsService.Spreadsheets.Values.Update
                (
                new Google.Apis.Sheets.v4.Data.ValueRange { Values = new List<IList<object>>(values) },
                spreadsheetId: _spreadsheetFileId,
                range: range
                );
            request.ValueInputOption = SpreadsheetsResource.ValuesResource.UpdateRequest.ValueInputOptionEnum.USERENTERED;
            UpdateValuesResponse response = request.Execute();

        }
        internal uint AppendRow(string Sheet, object[] Values)
        {
            SpreadsheetsResource.ValuesResource.GetRequest getReq = _sheetsService.Spreadsheets.Values.Get
                (
                    spreadsheetId: _spreadsheetFileId,
                    range: $"{Sheet}!A1:A1000000"
                );
            Google.Apis.Sheets.v4.Data.ValueRange getResp;
            getResp = getReq.Execute();

            var RowNumber = getResp.Values.Count+1;

            var values = new List<List<object>> { new List<object>(Values) };
            SpreadsheetsResource.ValuesResource.AppendRequest request = _sheetsService.Spreadsheets.Values.Append
                (
                body: new Google.Apis.Sheets.v4.Data.ValueRange { Values = new List<IList<object>>(values) },
                spreadsheetId: _spreadsheetFileId,
                range: $"{Sheet}!A{RowNumber}:{RowNumber}"
                );
            request.ValueInputOption = SpreadsheetsResource.ValuesResource.AppendRequest.ValueInputOptionEnum.USERENTERED;
            AppendValuesResponse response = request.Execute();
            return (uint)RowNumber;
        }
        internal object[] GetRange(string Sheet, uint RowNumber)
        {
            string range = $"INDIRECT(\"{Sheet}!R{RowNumber}C1:R{RowNumber}]\"; FALSE)";
            range = $"{Sheet}!A{RowNumber}:{RowNumber}";
            SpreadsheetsResource.ValuesResource.GetRequest request = _sheetsService.Spreadsheets.Values.Get
                (
                spreadsheetId: _spreadsheetFileId,
                range: range
                );
            var response = request.Execute();
            return response.Values[0].ToArray();
            return null;
        }
        private DataTable/*IList<object>*/ GetTable(string Sheet)
        {
            //maximum row of table: https://support.google.com/drive/answer/37603?hl=ru#:~:text=%D0%94%D0%BE%2050%20000%20%D1%81%D1%82%D1%80%D0%BE%D0%BA%20%D0%B8%D0%BB%D0%B8,%D0%B8%20%D0%B8%D0%B7%D0%B2%D0%BB%D0%B5%D1%87%D0%B5%D0%BD%D0%B8%D0%B9%20%D0%B8%D0%B7%20%D0%BF%D0%BE%D0%B4%D0%BA%D0%BB%D1%8E%D1%87%D0%B5%D0%BD%D0%BD%D1%8B%D1%85%20%D1%82%D0%B0%D0%B1%D0%BB%D0%B8%D1%86.
            string range = $"{Sheet}!A1:1000000";
            SpreadsheetsResource.ValuesResource.GetRequest request = _sheetsService.Spreadsheets.Values.Get
                (
                spreadsheetId: _spreadsheetFileId,
                range: range
                );
            Google.Apis.Sheets.v4.Data.ValueRange response = request.Execute();
            System.Data.DataTable dataTable = new System.Data.DataTable(Sheet);
            object[] listData = response.Values.ToArray();
            foreach (object colName in (List<object>)listData[0])
                dataTable.Columns.Add((string)colName);
            dataTable.Columns[0].DataType = typeof(uint);
            dataTable.Columns[1].DataType = typeof(DateTime);
            dataTable.Columns[2].DataType = typeof(string);
            dataTable.Columns[3].DataType = typeof(sbyte);
            for (int i = 1; i < listData.Length; i++)
                /*foreach (object cell in (List<object>)listData[i])
                {
                    dataTable.Rows.Add(
                }*/
                dataTable.Rows.Add(((List<object>)listData[i]).ToArray());

            return dataTable;
        }
        internal void FillTableFromFile(DataTable tbl)
        {
            string range = $"{tbl.TableName}!A1:1000000";
            List<object> insertedData;
            int attemtCounter = 0;
            bool requestRecived = false;
            //_sheetsService.Spreadsheets.GetByDataFilter(
            SpreadsheetsResource.ValuesResource.GetRequest request = _sheetsService.Spreadsheets.Values.Get
                (
                spreadsheetId: _spreadsheetFileId,
                range: range
                );
            Google.Apis.Sheets.v4.Data.ValueRange response = null;
            while (attemtCounter < 2 && !requestRecived)
            {
                try
                {
                    response = request.Execute();
                    requestRecived = true;
                }
                catch (System.Net.Http.HttpRequestException ex)
                {
                    attemtCounter++;
                }
            }
            object[] listData = response.Values.ToArray();
            List<object> importedColumns = (List<object>)listData[0];
            for (int i = 0; i < importedColumns.Count; i++)
                //dataTable.Columns.Add((string)colName);
                if (tbl.Columns[i + 1].ColumnName != importedColumns[i].ToString())
                    throw new Exception($"Impossible get data for table {tbl.TableName}. Column {i} have uninspected name {importedColumns[i].ToString()} instead of {tbl.Columns[i].ColumnName}");
            tbl.Rows.Clear();
            for (int i = 1; i < listData.Length; i++)
                try
                {
                    insertedData = (List<object>)listData[i];
                    insertedData.Insert(0, (uint)i + 1);
                    //tbl.Rows.Add(((List<object>)listData[i]).ToArray());
                    tbl.Rows.Add(insertedData.ToArray());

                    //foreach (object v in importedColumns) {
                    //tbl.Rows.Add(
                }
                catch (Exception ex)
                {
                    throw ex;
                }

        }

        private DataTable BuildJournal()
        {
            DataTable jrn = new DataTable(Tables.JOURNAL.ToString());
            jrn.Columns.Add("HOUR", typeof(TableVal));
            DataRow jrnHourRow;
            DataRow[] hoursRows;
            foreach (DataRow row in MainDataSet.Tables[Tables.CLIENTS.ToString()].Select("IS_ACTIVE = TRUE", "ORDER ASC"))
                jrn.Columns.Add((string)row["NAME"], typeof(TableVal));

            hoursRows = MainDataSet.Tables[Tables.HOURS.ToString()].Select("", "TIME ASC");
            foreach (DataRow row in hoursRows)
            {
                // this need for grouping. If jrn is empty or time in last row <> time in current row of Hours - add new row to journal,
                // else update current row
                if (jrn.Rows.Count == 0 || (DateTime)(((TableVal)jrn.Rows[jrn.Rows.Count - 1]["HOUR"]).Val) != (DateTime)row["TIME"])
                {
                    jrnHourRow = jrn.NewRow();
                    jrnHourRow["HOUR"] = new TableVal(Val: (DateTime)row["TIME"], RowNumber: (uint)row["ROW_ID"]);
                }
                else
                {
                    jrnHourRow = jrn.Rows[jrn.Rows.Count - 1];
                    ((TableVal)jrnHourRow["HOUR"]).AddRowNumber((uint)row["ROW_ID"]);
                }
                try
                {
                    jrnHourRow[row["CLIENT"].ToString()] = new TableVal(Val: /*(sbyte)*/row["STATUS"], RowNumber: (uint)row["ROW_ID"]);
                }
                //if client not present in active clients, colomn for this client will be added to jrn
                catch (ArgumentException ex)
                {
                    if (jrn.Columns[row["CLIENT"].ToString()] != null)
                        throw ex;
                    jrn.Columns.Add(row["CLIENT"].ToString());
                    jrnHourRow[row["CLIENT"].ToString()] = new TableVal(Val: (sbyte)row["STATUS"], RowNumber: (uint)row["#ROWNUM"]);
                }
                if (jrnHourRow.RowState == DataRowState.Detached) // if need update current row no need adding
                    jrn.Rows.Add(jrnHourRow);
            }
            jrn.ColumnChanged += Journal_ColumnChanged;
            return jrn;
        }

        private void Journal_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            TableVal v = (TableVal)(e.ProposedValue);
            //if (((TableVal)e.Row[e.Column]).CompareTo(v) == 0) return;
            uint[] rowIds = v.RowNumbers;
            object val = v.Val;
            DataRow[] rowsById;
            DataTable tbl = MainDataSet.Tables[Tables.HOURS.ToString()];
            uint rowId;
            //foreach (uint rowId in rowIds)
            for (int i = 0; i < rowIds.Length; i++)
            {
                rowId = rowIds[i];
                if (rowId == 0)
                {
                    //v = new TableVal(val, NewId());
                    //{"ROW_ID", "TIME", "CLIENT", "STATUS"},
                    rowId = NewId();
                    TableVal dvH = (TableVal)e.Row["HOUR"];
                    DateTime h = (DateTime)dvH.Val;
                    string c = e.Column.ColumnName;
                    tbl.Rows.Add(0, rowId, h, c, val);
                    //DataRow dr = tbl.NewRow();
                    //dr["#ROWNUM"] = 0;
                    //dr["ROW_ID"] = rId;
                    //dr["TIME"] = h;
                    //dr["CLIENT"] = c;
                    //dr["STATUS"] = val;
                    //v = new TableVal(v.Val, rowId);
                    v.UpdateDefaultId(rowId);
                    //e.ProposedValue = v;
                    //e.Row[e.Column] = v;
                    continue;
                }
                rowsById = tbl.Select($"ROW_ID='{rowId}'");
                if (rowsById.Length != 1)
                    if (rowsById.Length == 0) throw new Exception($"Not found ROW_ID = '{rowId}' in table {tbl.TableName}");
                    else throw new Exception($"ROW_ID {rowId} is not unique in {tbl.TableName}");
                rowsById[0][e.Column.ColumnName == "HOUR" ? "TIME" : "STATUS"] = val;
            }
        }
        private void FileTable_ColumnChanged(object sender, DataColumnChangeEventArgs e)
        {
            DataTable dt = (DataTable)sender;
            if (e.Column.ColumnName == "#ROWNUM" || e.Column.ColumnName == "ROW_ID") return;
            uint dataSheetRowNum = (uint)e.Row["#ROWNUM"];
            /*object[] vals = new object[dt.Columns.Count - 1];
            for (int i = 1; i < dt.Columns.Count; i++)
                vals[i - 1] = e.Row[i];*/
            SetRow(dt.TableName, dataSheetRowNum, e.Row.ItemArray[1..]);
            //AppendRow(dt.TableName, dataSheetRowNum, e.Row.ItemArray[1..]);
            //throw new NotImplementedException();
        }
        private void FileTable_NewRow(object sender, DataRowChangeEventArgs e)
        {
            //if (e.Action!=DataRowAction.Add
            DataTable dt = (DataTable)sender;
            switch (e.Action)
            {
                case DataRowAction.Add:
                    uint newRowNum = AppendRow(dt.TableName, e.Row.ItemArray[1..]);
                    e.Row[0/*"#ROWNUMBER"*/] = newRowNum;
                    break;
                case DataRowAction.Change:
                    // processed in ColumnCahnged
                    return;
                default:
                    throw new Exception($"Dont now what I can do with {e.Action} for row");
            }



        }
        private uint NewId()
        {
            //this function must be rewrited
            Random rnd = new Random();
            return (uint)rnd.NextInt64();
        }
    }
    struct TableDifinitions
    {

        public TableDifinitions(string Name, string[] ColumnNames, Type[] ColumnDatatypes)
        {
            if (ColumnNames.Length != ColumnDatatypes.Length)
                throw new Exception($"Count of columns {ColumnNames.Length} not equal count of datatypes {ColumnDatatypes.Length}");
            this.Name = Name;
            this.ColumnDatatypes = ColumnDatatypes;
            this.ColumnNames = ColumnNames;
        }
        public string Name { get; private set; }
        public string[] ColumnNames { get; private set; }
        public Type[] ColumnDatatypes { get; set; }
        public DataTable NewTable()
        {
            DataTable table = new DataTable(Name);
            table.Columns.Add("#ROWNUM", typeof(uint));
            for (int i = 0; i < ColumnNames.Length; i++)
                table.Columns.Add(ColumnNames[i], ColumnDatatypes[i]);
            //table.ColumnChanged += FileTable_ColumnChanged;
            return table;
        }


    }
}
