﻿namespace EK_Table
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnSetting = new Button();
            btnDB = new Button();
            dgvJournal = new DataGridView();
            dsJournal = new BindingSource(components);
            ((System.ComponentModel.ISupportInitialize)dgvJournal).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dsJournal).BeginInit();
            SuspendLayout();
            // 
            // btnSetting
            // 
            btnSetting.Location = new Point(378, 30);
            btnSetting.Name = "btnSetting";
            btnSetting.Size = new Size(75, 23);
            btnSetting.TabIndex = 0;
            btnSetting.Text = "Settings";
            btnSetting.UseVisualStyleBackColor = true;
            btnSetting.Click += btnSetting_Click;
            // 
            // btnDB
            // 
            btnDB.Location = new Point(471, 30);
            btnDB.Name = "btnDB";
            btnDB.Size = new Size(75, 23);
            btnDB.TabIndex = 1;
            btnDB.Text = "button1";
            btnDB.UseVisualStyleBackColor = true;
            btnDB.Click += btnDB_Click;
            // 
            // dgvJournal
            // 
            dgvJournal.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dgvJournal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvJournal.Location = new Point(12, 59);
            dgvJournal.Name = "dgvJournal";
            dgvJournal.RowTemplate.Height = 25;
            dgvJournal.Size = new Size(785, 379);
            dgvJournal.TabIndex = 2;
            dgvJournal.CellBeginEdit += dgvJournal_CellBeginEdit;
            dgvJournal.CellEndEdit += dgvJournal_CellEndEdit;
            dgvJournal.CellErrorTextChanged += dgvJournal_CellErrorTextChanged;
            dgvJournal.CellErrorTextNeeded += dgvJournal_CellErrorTextNeeded;
            dgvJournal.CellValueNeeded += dgvJournal_CellValueNeeded;
            dgvJournal.CellValuePushed += dgvJournal_CellValuePushed;
            dgvJournal.DataError += dgvJournal_DataError;
            dgvJournal.RowsAdded += dgvJournal_RowsAdded;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(dgvJournal);
            Controls.Add(btnDB);
            Controls.Add(btnSetting);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dgvJournal).EndInit();
            ((System.ComponentModel.ISupportInitialize)dsJournal).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Button btnSetting;
        private Button btnDB;
        private DataGridView dgvJournal;
        private BindingSource dsJournal;
    }
}